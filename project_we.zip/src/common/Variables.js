export default {

    IsLive: false,
    LocalApiBaseUrl: "http://localhost:5000/",
    LiveApiBaseUrl: false,
   
   
};